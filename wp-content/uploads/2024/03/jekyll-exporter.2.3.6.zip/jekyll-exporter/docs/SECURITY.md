# Security Policy

To report a security vulnerability, please email [ben@balter.com](mailto:ben@balter.com).
